let videos = ['https://www.youtube.com/embed/Tz1A9V_mA6I'];

function setup() {
    noCanvas();
    loadVideos();
    document.getElementById('addVideoButton').addEventListener('click', addVideo);
}

function loadVideos() {
    let mainVideoContainer = document.getElementById('mainVideo');
    let galleryContainer = document.getElementById('gallery');
    mainVideoContainer.innerHTML = '';
    galleryContainer.innerHTML = '';
    
    let mainVideo = document.createElement('iframe');
    mainVideo.src = videos[0];
    mainVideo.width = '100%';
    mainVideo.height = '400px';
    mainVideo.frameBorder = '0';
    mainVideo.allowFullscreen = true;
    mainVideoContainer.appendChild(mainVideo);

    for (let i = 1; i < videos.length; i++) {
        let smallVideo = document.createElement('iframe');
        smallVideo.src = videos[i];
        smallVideo.className = 'video-small';
        smallVideo.frameBorder = '0';
        smallVideo.allowFullscreen = true;
        galleryContainer.appendChild(smallVideo);
    }
}

function addVideo() {
    let input = document.getElementById('searchInput').value;
    if (input) {
        videos.push(input);
        loadVideos();
    }
}
